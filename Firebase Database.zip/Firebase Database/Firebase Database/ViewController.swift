//
//  ViewController.swift
//  Firebase Database
//
//  Created by MAC on 19/07/21.
//  Copyright © 2021 com.genesis.demo. All rights reserved.
//

import UIKit
import Firebase
class ViewController: UIViewController {

    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        txtEmail.autocorrectionType = .no
        txtPassword.autocorrectionType = .no

        // Do any additional setup after loading the view.
    }


    @IBAction func ClickToRegister(_ sender: Any) {
        createUser()
        
    }
    
    @IBAction func ClickToLogIn(_ sender: Any) {
        loginUser()
    }
    @IBAction func ClickToForgetPassword(_ sender: Any) {
        forgetpasswordUser()
    }
    
    func createUser(){
        Auth.auth().createUser(withEmail: txtEmail.text!, password: txtPassword.text!) { (user, error) in
            if error != nil {
                
            } else {
                print("Success Create")
            }
        }
    }
    
    func loginUser(){
        Auth.auth().signIn(withEmail: txtEmail.text!, password: txtPassword.text!) { (user, error) in
            if error != nil {
                print("Error....")
            
            } else {
                print("Success LogIn")
            }
        }
    }
    
    func forgetpasswordUser(){
        Auth.auth().sendPasswordReset(withEmail: txtEmail.text!){ (error) in

//            self.txtEmail.text = ""
        
            if let error = error {
                print(error.localizedDescription)
            }
            else {
                print("Check Email And Reset Your Password")
            }
        }
    }
}

